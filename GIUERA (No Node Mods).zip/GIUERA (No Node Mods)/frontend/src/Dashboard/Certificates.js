import React from 'react'


class Certificates extends React.Component{
	constructor(props){
		super(props)

		this.state={
			user:null,
		}


	}

	render=()=>{
		return(
		<>
		</>

		)
	}
}


export default Certificates