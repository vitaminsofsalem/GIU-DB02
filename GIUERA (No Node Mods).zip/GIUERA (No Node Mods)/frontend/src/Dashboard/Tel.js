import React from 'react'
import DashboardStyles from './DashboardStyles'

class Tel extends React.Component{

	constructor(props){
		super(props);
		this.state ={ 
			user = props.user,
		};

		
	}


}

export default Tel;