
const Scrollable = (props) =>

		(
					<div style={{overflowY:"scroll"}}>
						{props.children}	
					</div>

		)

export default Scrollable